# audio-test-app
R Shiny app to record speech

This is the beginning of an app designed to record speech for speech production and perception experiments for researchers familiar with R. It currently is set up only for a speech production experiment, but eventually we hope to expand to allow functionalities for perception experiments as well. Stay tuned! 

You can find a working demo of the app at here: https://abbeythomas.shinyapps.io/audio_test_app2/
