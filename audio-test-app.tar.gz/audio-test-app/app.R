library(shiny)
library(shinyWidgets)
library(shinyjs)
library(RCurl)
library(tidyverse)
library(ggplot2)
library(rdrop2)


addResourcePath("WAR", "WAR")

mandatory <- c("comp","sc","mic")

# Function to get system time so we can save the data later. 
getTime <- function() {
  return(as.integer(Sys.time()))
}

addInfo <- function(new_data){
  metadata <- drop_read_csv("app_metadata/metadata.csv")
  fp1 <- file.path(tempdir(), paste0("metadata", as.character(Sys.time()), ".csv"))
  write.csv(metadata, fp1, row.names = FALSE)
  drop_upload(fp1, path = "app_metadata")
  meta_new <- rbind(metadata, new_data)
  
  numbers <- meta_new %>% rownames_to_column() %>% 
    filter(rowname == max(as.numeric(rowname))) 
  
  pin <<- (as.numeric(numbers$rowname[1])) + 999
  
  with_pin <- meta_new %>% 
    mutate(PIN = ifelse(PIN == "x", as.character(pin), as.character(PIN)))
  fp2 <- file.path(tempdir(), "metadata.csv")
  write.csv(with_pin, fp2, row.names = FALSE)
  drop_upload(fp2, path = "app_metadata", mode = "overwrite", 
              autorename = FALSE,)
  return(pin)
}

# Randomly order the destinations to be matched
colOrder <- function(n, columns, file) {
  # file where the icon and actionButton IDs are stored
  f <- read.csv(as.character(file))
  
  # create vector to order by columns
  c <- c(rep(c(1:columns), length.out = n))
  
  # return column order for use in later functions
  col_order <- as.data.frame(cbind(c,f)) %>% arrange(c)
  
  return(col_order)
}

destOrder <- function(n, file) {
  # file where the icon and actionButton IDs are stored
  f <- read.csv(as.character(file))
  
  # n = length of the sample
  s <- sample(c(1:n), size = as.numeric(n))
  
  # create randomly ordered df
  dest_order <- as.data.frame(cbind(s,f)) %>% arrange(s)
  
  return(dest_order)
}

# Get column of buttons
bttnColumn <- function(df, rows, level) {
  buttons <- list()
  for (i in rows) {
    buttons[[i]] <- actionButton(inputId = paste0(col_order$button[i], level), 
                                 label = character(0),
                                 icon = icon("question-circle"),
                                 style = paste0("background-color:#", 
                                                col_order$hex[i], 
                                                "; font-size:200%"))
  }
  return(buttons)
  
}

# Get block stimuli 

getBlockStimuli <- function(df, level) {
  stimuli <- df %>% filter(block == level)
  return(stimuli)
}

# UI ----

ui <- tagList(
  ## Load other scripts----
  tags$head(tags$style(HTML('.navbar-nav a {cursor: default}'))),
  
  navbarPage(id = "tabs", selected = "intro",
             useShinyjs(),
             extendShinyjs("extend.js", functions = c("webAudioRecorder")), 
             includeScript("WAR/WebAudioRecorder.min.js"),
             includeScript("WAR/volume-meter.js"),
             includeCSS("www/styles.css"),
             
             ## Entry----
             tabPanel(title = "Introduction", value = "intro",
                      h3(id = "game_intro", "Welcome to Speech Perception Investigative Enterprises, or as it's known around here, S.P.I.E.s. We have a training game set up especially for you. If you are ready for the mission, click the door to enter our headquarters and begin your mission."),
                      div(id = "door1div", style = "text-align:center;",
                          actionButton("HQ_entry", 
                                       label = img(src = "door_HQ.png", 
                                                   type = "image/png", 
                                                   alt = "door", 
                                                   height = "600", 
                                                   width = "500"))),
                      uiOutput(outputId = "hq_bg"), 
                      
                      ### Device info----
                      hidden(h1(id = "dev_header", "Device Information"),
                             p(id = "dev_req", "This experiment will require us to record your voice from your computer. (NOTE: You will only be recorded between the time you click RECORD and the time you click STOP.) To complete this process, we need some more information about your equipment to understand how your recordings are being processed before they get to us. All questions on this page require an answer.")),
                      hidden(textInput(inputId = "comp", label = "What is the brand and model of the computer you are using for this experiment? Just give us as much information as you know (e.g., Macbook pro, 2015).", width = "800px")),  
                      hidden(textInput(inputId = "sc", label = "What soundcard does your computer use? If you are using a Mac and have not performed any hardware upgrades, simply type 'Mac, original hardware' in the box above. On a Windows PC, go to 'Device Manager', then expand the 'Sound, video, and game controllers' menu. Your soundcard should be on that list, usually last. If you cannot find the information, just type 'I don't know.'", width = "800px")),  
                      hidden(textInput(inputId = "mic", label = "What microphone are you using? If you are using the computer's built-in microphone, just type 'built in microphone'. Otherwise, please tell us as much as you know about the microphone you are using.", width = "800px")),
                      hidden(disabled(actionButton("submit_dev", "Submit"))),
                      
                      ### Pin assignment----
                      hidden(h3(id = "pin_intro", "You will now be assigned an ID number to maintain your secret identity. If for any reason (internet failure, etc.) you cannot finish the game in one sitting, you may enter this number to resume your mission. Please write this number down and keep it in a secure location. Click READY when you've recorded your ID number and are ready to begin.")),
                      hidden(div(id = "pin_here", style = "text-align:center;",
                                 h5(textOutput("show_pin")))),
                      hidden(actionButton("pin_done", "READY"))
             ),
             
             ## Level 1----
             
             ### Intro page----
             tabPanel(title = "Level 1", value = "level1", 
                      uiOutput(outputId = "map_bg"),
                      fluidRow(
                        column(
                          width = 6, 
                          offset = 3, 
                          
                      div(id = "intro1", align = "center", style = "vertical-align:middle",
                          h3(id = "l1_title","Level 1: Training", align = "center"), 
                          h5(id = "l1_intro", "In this level we'll need you to use your memory powers to memorize a map of the city. You'll be speaking with witnesses at each location. Remember to keep your cool and sound natural. You're trying to blend in, so you'll be asked to make statements about where you've been too. No one likes someone who just runs around questioning everyone; that's rather suspicious. Act natural. Only when you have proven your knowledge of the city will you be able to move on to the real detective work in Level 2!"),
                          actionButton(inputId = "l1_start", "Begin Level 1")
                      )
                      )),
                      
                      ### Main page----
                      fluidRow(div(id = "main1", align = "center", 
                          h4(textOutput(outputId = "dest_text1")),
                          uiOutput(outputId = "destUI1"),
                          br(),
                          uiOutput(outputId = "destButtons1")
                      ))
             ),
             
             ## Level 2----
             
             ### Intro page----
             tabPanel(title = "Level 2", value = "level2", 
                      uiOutput(outputId = "town_bg"),
                      fluidRow(
                        column(
                          width = 6, 
                          offset = 3, 
                          
                      div(id = "intro2", align = "center", style = "vertical-align:middle",
                          h3(id = "l2_title","Level 2: Trust the Townspeople"), 
                          h5(id = "l2_intro", "Agent, our town needs your help! It appears that in the wake of a ravaging storm, someone took advantage of the chaos to break into bank and steal the people's money. The townspeople are frightened and many of their homes were destroyed. A senior agent has already questioned them once, and none of them are suspects. They are all willing to help. Your tone of voice should convey that you trust them and sympathize with them."),
                          actionButton(inputId = "l2_start", "Begin Level 2")
                      )
                      
                      )),
                      
                      ### Main page----
                      fluidRow(div(id = "main2", align = "center", 
                          h4(textOutput(outputId = "dest_text2")),
                          uiOutput(outputId = "destUI2"),
                          br(),
                          uiOutput(outputId = "destButtons2")
                      ))
             ),
             
             ## Level 3----
             tabPanel(title = "Level 3", value = "level3",
                      uiOutput(outputId = "hq_bg2"),
                      fluidRow(
                        column(
                          width = 6,
                          offset = 3,
                        div(id = "intro3", align = "center", style = "vertical-align:middle", 
                          h3(id = "l3_title","Level 3: Don't Trust the Villain!"), 
                          h5(id = "l3_intro", "Alright, it's your witness, Agent. You've found the thief. Now you'll need to question him. He's already been questioned a few times, and we most of what he says has been proven false. You shouldn't believe his answers, so use your tone of voice to make sure he knows that. We've tried the 'good cop' routine with this character, so we'd like to see what happens when he knows you're suspicious of him and his lies! Each of your questions, if asked properly, will be rewarded with some of the people's money found and returned. Once you have found it all, your task will be complete."),
                          actionButton(inputId = "l3_start", "Begin Level 3"))
                      
                      )),
                      
                      fluidRow(
                        div(id = "main3", align = "center", 
                            h4(textOutput(outputId = "dest_text3")),
                            uiOutput(outputId = "destUI3"),
                            br(),
                            uiOutput(outputId = "destButtons3")
                        )
                      )
                      
             ), 
             
             tabPanel(title = "Recording", value = "recording",
                      br(),
                      fluidRow(
                        column(
                          width = 6, 
                          offset = 3,
                        div(id = "rec_page", align = "center", style = "background-color:rgba(248,248,255,0.4)", 
                          hidden(div(id = "stimDiv", h2(textOutput(outputId = "stimulus")))),
                          actionButton("record", "Record"),
                          disabled(actionButton("stop", "Stop"))), 
                      
                      ### Done----
                      hidden(div(id = "done", align = "center", style = "vertical-align:middle", 
                                 h3(id = "miss_acc", "Mission accomplished!"), 
                                 h5(id = "complete", "Great job, Agent! All recordings are complete and saved. You may now close your browser window. Thank you for your participation!"))
                      )))
             )
            
             
  ))

# Server----
server <- function(input, output, session) {
  ## Get authorization for dropbox----
  drop_auth(rdstoken = "droptoken.RDS")
  
  ## Disable navbar----
  shinyjs::disable(selector = '.navbar-nav a')
  
  ## Create counter----
  counter <- reactiveValues(n = 1, lvl = 1)
  
  ## Read data frame of stimuli----
  all_stim <- read.csv("www/FYP_stimuli_short.csv")
  
  ## Intro page----
  ### Order destinations----
  dest_order <<- destOrder(n = 24, file = "destination_buttons.csv")
  col_order <<- colOrder(n = 24, columns = 4, file = "destination_buttons.csv")
  
  ### Set background----
  output$hq_bg <- renderUI({
    setBackgroundImage(src = "hq_bg.jpg")
  })
  
  ### Information input----
  
  ### Show information input page when door is clicked
  observeEvent(input$HQ_entry, {
    hide("game_intro")
    hide("door1div")
    
    showElement("dev_header")
    showElement("dev_req")
    showElement("comp")  
    showElement("sc")  
    showElement("mic")
    showElement("submit_dev", "Submit")
  })
  
  ### Function to make sure all information fields are filled
  observe({
    mandatoryFilled <-
      vapply(mandatory,
             function(x) {
               !is.null(input[[x]]) && input[[x]] != ""
             },
             logical(1))
    mandatoryFilled <- all(mandatoryFilled)
    
    shinyjs::toggleState(id = "submit_dev", 
                         condition = mandatoryFilled)
  })
  
  ### Function to make sure all information fields are filled
  observe({
    mandatoryFilled <-
      vapply(mandatory,
             function(x) {
               !is.null(input[[x]]) && input[[x]] != ""
             },
             logical(1))
    mandatoryFilled <- all(mandatoryFilled)
    
    shinyjs::toggleState(id = "submit_dev", 
                         condition = mandatoryFilled)
  })
  
  ### store metadata----
  formInfo <- reactive({
    meta <- sapply(c(mandatory), function(x) input[[x]])
    meta <- c(meta, timestamp = getTime(), PIN = "x")
    meta <- t(meta)
    meta
  })
  
  ### Get pin----
  observeEvent(input$submit_dev, {
    addInfo(formInfo())
    hide("dev_header")
    hide("dev_req")
    hide("comp")  
    hide("sc")  
    hide("mic")
    hide("submit_dev", "Submit")
    
    showElement("pin_intro")
    output$show_pin <- renderText({paste0("You will now be know as Agent #", pin)})
    showElement("pin_here")
    showElement("pin_done")
  })
  
  ## Move to Lvl 1----
  observeEvent(input$pin_done, {
    updateTabsetPanel(session, "tabs", selected = "level1")
    
    ### Make directory for user's recordings on Dropbox----
    drop_create(path = paste0("pilot", pin))
    
    ### Set background----
    output$map_bg <- renderUI({
      setBackgroundImage(src = "map_bg.jpg")
    })
    
    
  })
  
  observeEvent(input[[paste0("l", counter$lvl, "_start")]], {
    hide(paste0("l", counter$lvl, "_intro"))
    hide(paste0("l", counter$lvl, "_start"))
    stimuli <<- getBlockStimuli(all_stim, level = counter$lvl)
    output[[paste0("dest_text", counter$lvl)]] <- renderText({paste0("Your current destination is the ", dest_order$place[counter$n])})
    output[[paste0("destUI", counter$lvl)]] <- renderUI({
      actionButton(inputId = paste0(dest_order$button[counter$n]), 
                   label = character(0),
                   icon = icon(paste0(dest_order$icon[counter$n])),
                   style = paste0("background-color:#", 
                                  dest_order$hex[counter$n], 
                                  "; font-size:200%"))
    })
    
    output[[paste0("destButtons", counter$lvl)]] <- renderUI({
      fluidRow(
        column(width = 1, offset = 4,
               bttnColumn(col_order, c(1:6), level = counter$lvl)),
        column(width = 1,
               bttnColumn(col_order, c(7:12), level = counter$lvl)),
        column(width = 1, 
               bttnColumn(col_order, c(13:18), level = counter$lvl)),
        column(width = 1, 
               bttnColumn(col_order, c(19:24), level = counter$lvl))
      )
      
    })
  })
  
  # What to do if they got it right
  observeEvent(input[[paste0(dest_order$button[counter$n], counter$lvl)]], {
    # Reveal the answer
    updateActionButton(session = session, 
                       inputId = paste0(dest_order$button[counter$n], counter$lvl),
                       label = character(0),
                       icon = icon(paste0(dest_order$icon[counter$n])))
    # then cover it back up and hide the destination text and button after a second
    delay(1000,updateActionButton(session = session, 
                       inputId = paste0(dest_order$button[counter$n], counter$lvl),
                       label = character(0),
                       icon = icon("question-circle")))
    delay(1000, hide(paste0("dest_text", counter$lvl)))
    delay(1000, hide(paste0("destUI", counter$lvl)))
    # Move to the Recording tab
    delay(1200, updateTabsetPanel(session, "tabs", selected = "recording"))
  })
  
  ## Record----
  observe(
    js$webAudioRecorder("wav")
  )
  
  observeEvent(input$record, { 
    if (counter$n == 1) {
      
      # Wait for participant to enable mic to show stimulus
      observeEvent(input$ready, {
        
        # Add to the counter
        counter$n <- counter$n + 1 
        # Disable record once user gives permission to the microphone. 
        disable("record")
        
        # Show the stimulus
        delay(500, showElement("stimDiv"))
        output$stimulus <- renderText({paste0(stimuli$sentence[counter$n-1])})
        
        # Enable the stop button after 500 ms
        delay(500, enable("stop"))
      })
      
      observeEvent(input$audio, 
                   {
                     # Decode wav file.
                     audio <- input$audio
                     audio <- gsub('data:audio/wav;base64,', '', audio)
                     audio <- gsub(' ', '+', audio)
                     audio <- base64Decode(audio, mode = 'raw')
                     
                     # Save to file on server.
                     inFile <- list()
                     inFile$datapath <- file.path(tempdir(), paste0(pin, "_", stimuli$filename[counter$n-1]))
                     inFile$file <- file(inFile$datapath, 'wb')
                     writeBin(audio, inFile$file)
                     drop_upload(inFile$datapath, path = paste0("pilot", pin))
                     close(inFile$file) 
                   })
      
    } else {
      
      if (input$ready == "yes") {
        
        # Add to the counter 
        counter$n <- counter$n + 1 
        
        # Disable record once user gives permission to the microphone. 
        disable("record")
        
        # Show the stimulus
        delay(500, showElement("stimDiv"))
        output$stimulus <- renderText({paste0(stimuli$sentence[counter$n-1])})
        
        # Enable the stop button after 1500 ms
        delay(1500, enable("stop"))
      }
      
      observeEvent(input$audio, 
                   {
                     # Decode wav file.
                     audio <- input$audio
                     audio <- gsub('data:audio/wav;base64,', '', audio)
                     audio <- gsub(' ', '+', audio)
                     audio <- base64Decode(audio, mode = 'raw')
                     
                     # Save to file on server.
                     inFile <- list()
                     inFile$datapath <- file.path(tempdir(), paste0(pin, "_", stimuli$filename[counter$n-1]))
                     inFile$file <- file(inFile$datapath, 'wb')
                     writeBin(audio, inFile$file)
                     drop_upload(inFile$datapath, path = paste0("pilot", pin))
                     close(inFile$file) 
                   })
    }
    
  })
  
  observeEvent(input$stop, {
    disable("stop")
    hide("stimDiv")
    delay(2000, enable("record"))
    if (counter$n <= nrow(stimuli)) {
      output[[paste0("dest_text", counter$lvl)]] <- renderText(paste0("Your current destination is the ", dest_order$place[counter$n]))
      output[[paste0("destUI", counter$lvl)]] <- renderUI({
        actionButton(inputId = paste0(dest_order$button[counter$n]), 
                     label = character(0),
                     icon = icon(paste0(dest_order$icon[counter$n])),
                     style = paste0("background-color:#",  
                                    dest_order$hex[counter$n], 
                                    "; font-size:200%"))
      })
      updateTabsetPanel(session, "tabs", selected = paste0("level", counter$lvl))
      delay(1000, showElement(paste0("dest_text", counter$lvl)))
      delay(1000, showElement(paste0("destUI", counter$lvl)))
    } else if (counter$n > nrow(stimuli)) {
      if (counter$lvl == 1) {
        counter$n <- 1
        counter$lvl <- counter$lvl + 1
        
        output$town_bg <- renderUI({
          setBackgroundImage(src = "town_bg.jpg")})
        
        delay(1500, updateTabsetPanel(session, "tabs", selected = "level2"))
        
        ### Order destinations----
        
      } else if (counter$lvl == 2) {
        counter$n <- 1
        counter$lvl <- counter$lvl + 1
        
        output$hq_bg2 <- renderUI({
          setBackgroundImage(src = "hq_bg.jpg")
        })
        
        delay(1500, updateTabsetPanel(session, "tabs", selected = "level3"))
        
        ### Order destinations----
      } else if (counter$lvl == 3) {
        hide("rec_div")
        showElement("done")
      }
    }
  })
  
  
}

shinyApp(ui = ui, server = server)
