library(aws.s3)

# Are values stored in the WWW folder accessible? 
# Or do we need to "get object" to open each of those files?

# Will need to run these once for setup----
#s3BucketName <- "my-unique-s3-bucket-name"
#Sys.setenv("AWS_ACCESS_KEY_ID" = "key",
#           "AWS_SECRET_ACCESS_KEY" = "secret",
#           "AWS_DEFAULT_REGION" = "region")

#put_folder("app_metadata", bucket = s3BucketName)


# Loading metadata----
# Need to check that this method of reading in a file actually works. 
addInfo <- function(new_data){
  object <- get_object("app_metadata/metadata.csv", bucket = s3BucketName)
  obj_data <- readBin(object, "character")
  metadata <- read.csv("app_metadata/metadata.csv", stringsAsFactors = FALSE)
  
  tmp1 <- tempfile()
  write.csv(metadata, tmp1, row.names = FALSE)
  put_object(file = tmp1, object = paste0("app_metadata/metadata", 
                                         as.character(Sys.time()), ".csv"), 
             bucket = s3BucketName)
  
  meta_new <- rbind(metadata, new_data)
  
  numbers <- meta_new %>% rownames_to_column() %>% 
    filter(rowname == max(as.numeric(rowname))) 
  
  pin <<- (as.numeric(numbers$rowname[1])) + 999
  
  with_pin <- meta_new %>% 
    mutate(PIN = ifelse(PIN == "x", as.character(pin), as.character(PIN)))
  tmp2 <- tempfile()
  write.csv(with_pin, tmp2, row.names = FALSE)
  put_object(file = tmp2, object = "app_metadata/metadata.csv", 
             bucket = s3BucketName)
  
  return(pin)
}

# Line 324: creating user's directory----
put_folder(paste0("pilot", pin), bucket = s3BucketName)

# Saving audio recordings----
# This may or may not work with the present syntax, 
# since aws S3 likes unnamed files in the temp directory, but here's hoping...
observeEvent(input$audio, 
             {
               # Decode wav file.
               audio <- input$audio
               audio <- gsub('data:audio/wav;base64,', '', audio)
               audio <- gsub(' ', '+', audio)
               audio <- base64Decode(audio, mode = 'raw')
               
               # Save to file on server.
               inFile <- list()
               inFile$filename <- paste0("pilot",pin, "/",pin, "_", stimuli$filename[counter$n-1])
               inFile$datapath <- tempfile()
               inFile$file <- file(inFile$datapath, 'wb')
               writeBin(audio, inFile$file)
               put_object(file = inFile$datapath, object = inFile$filename, bucket = s3BucketName)
               close(inFile$file) 
             })

